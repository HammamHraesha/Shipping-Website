using System;

namespace ShippingWebsite.Models
{
    public class ErrorViewModel
    {
        
    }
}